package fxsrc.propyecto.enums;

public enum ItemTypes {

    BOOLEAN, INT, FLOAT, STRING, ARRAY_BOOLEAN, ARRAY_INT, ARRAY_FLOAT, ARRAY_STRING;
}
