package fxsrc.propyecto.enums;

public enum RatingAttributes {
    USER_ID, ITEM_ID, RATING;
}
