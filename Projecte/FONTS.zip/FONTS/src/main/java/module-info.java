module fxsrc.propyecto {
    requires javafx.base;
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;

    //requires org.kordamp.bootstrapfx.core;
    requires junit;
    requires org.mockito;
    requires controlsfx;

    exports fxsrc.propyecto.presentation;
    opens fxsrc.propyecto.presentation to javafx.fxml;
    exports fxsrc.propyecto.drivers;
    opens fxsrc.propyecto.drivers to javafx.fxml;
    exports fxsrc.propyecto.domain;
    opens fxsrc.propyecto.domain to javafx.fxml;
    exports fxsrc.propyecto.data;
    opens fxsrc.propyecto.data to javafx.fxml;
}