var classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test =
[
    [ "computeDCG", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html#a1bcecfb437aefca6fe51ac595aa59e97", null ],
    [ "computeIDCG", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html#ab73ee2eeb4d610b4516d9223b0ca7999", null ],
    [ "computeNDCG", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html#a085ff9cf05a174b86779c1dcf8b0a9d7", null ],
    [ "main", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html#ab5b998d00b353e2e354029feedfbb1cd", null ],
    [ "setUp", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html#a97aac09cca6d96e0df885125be2a2f62", null ],
    [ "cf", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html#aa24b0f93c1ca279f12866f3dd1b54203", null ],
    [ "DCG", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html#a96770434f8d5405c5be52056ba5188e9", null ],
    [ "IDCG", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html#a90d39758f74e933852ab695eca9a88ce", null ],
    [ "NDCG", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html#a60537e3e5b265c00a856715ae29a9084", null ],
    [ "predicted", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html#a84cfbdade6b588ea19cdea929470a107", null ]
];