var dir_6031c55975f8dbafe7655d44f81e65bc =
[
    [ "ItemTypes.java", "_item_types_8java.html", [
      [ "ItemTypes", "enumfxsrc_1_1propyecto_1_1enums_1_1_item_types.html", "enumfxsrc_1_1propyecto_1_1enums_1_1_item_types" ]
    ] ],
    [ "RatingAttributes.java", "_rating_attributes_8java.html", [
      [ "RatingAttributes", "enumfxsrc_1_1propyecto_1_1enums_1_1_rating_attributes.html", "enumfxsrc_1_1propyecto_1_1enums_1_1_rating_attributes" ]
    ] ]
];