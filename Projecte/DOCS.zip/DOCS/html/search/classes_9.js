var searchData=
[
  ['likedlistcontroller_697',['LikedListController',['../classfxsrc_1_1propyecto_1_1presentation_1_1_liked_list_controller.html',1,'fxsrc::propyecto::presentation']]],
  ['logincontroller_698',['LogInController',['../classfxsrc_1_1propyecto_1_1presentation_1_1_log_in_controller.html',1,'fxsrc::propyecto::presentation']]]
];
