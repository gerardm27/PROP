var searchData=
[
  ['collaborativefiltering_2ejava_727',['CollaborativeFiltering.java',['../_collaborative_filtering_8java.html',1,'']]],
  ['contentbasedfiltering_2ejava_728',['ContentBasedFiltering.java',['../_content_based_filtering_8java.html',1,'']]],
  ['contentbasedfilteringtest_2ejava_729',['ContentBasedFilteringTest.java',['../_content_based_filtering_test_8java.html',1,'']]],
  ['contentbasedfilteringtest_2etxt_730',['ContentBasedFilteringTest.txt',['../_content_based_filtering_test_8txt.html',1,'']]]
];
