var searchData=
[
  ['collaborativefiltering_670',['CollaborativeFiltering',['../classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html',1,'fxsrc::propyecto::domain']]],
  ['contentbasedfiltering_671',['ContentBasedFiltering',['../classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html',1,'fxsrc::propyecto::domain']]],
  ['contentbasedfilteringtest_672',['ContentBasedFilteringTest',['../classfxsrc_1_1propyecto_1_1drivers_1_1_content_based_filtering_test.html',1,'fxsrc::propyecto::drivers']]]
];
