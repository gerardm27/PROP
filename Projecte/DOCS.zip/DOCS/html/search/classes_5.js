var searchData=
[
  ['forgotpasscontroller_685',['ForgotPassController',['../classfxsrc_1_1propyecto_1_1presentation_1_1_forgot_pass_controller.html',1,'fxsrc::propyecto::presentation']]],
  ['frequencyandsumofscores_686',['FrequencyAndSumOfScores',['../classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering_1_1_frequency_and_sum_of_scores.html',1,'fxsrc::propyecto::domain::CollaborativeFiltering']]]
];
