var searchData=
[
  ['noexistingactiveuserexception_2ejava_762',['NoExistingActiveUserException.java',['../_no_existing_active_user_exception_8java.html',1,'']]],
  ['noexistinguseridexception_2ejava_763',['NoExistingUserIDException.java',['../_no_existing_user_i_d_exception_8java.html',1,'']]]
];
