var searchData=
[
  ['noexistingactiveuserexception_699',['NoExistingActiveUserException',['../classfxsrc_1_1propyecto_1_1domain_1_1_no_existing_active_user_exception.html',1,'fxsrc::propyecto::domain']]],
  ['noexistinguseridexception_700',['NoExistingUserIDException',['../classfxsrc_1_1propyecto_1_1domain_1_1_no_existing_user_i_d_exception.html',1,'fxsrc::propyecto::domain']]]
];
