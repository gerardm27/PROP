var dir_b9ed2ce6690130d6f8f4227dfaa037d1 =
[
    [ "AlgorithmTester.java", "_algorithm_tester_8java.html", [
      [ "AlgorithmTester", "classfxsrc_1_1propyecto_1_1domain_1_1_algorithm_tester.html", "classfxsrc_1_1propyecto_1_1domain_1_1_algorithm_tester" ]
    ] ],
    [ "AttValDoesNotExistException.java", "_att_val_does_not_exist_exception_8java.html", [
      [ "AttValDoesNotExistException", "classfxsrc_1_1propyecto_1_1domain_1_1_att_val_does_not_exist_exception.html", "classfxsrc_1_1propyecto_1_1domain_1_1_att_val_does_not_exist_exception" ]
    ] ],
    [ "BadCredentialsException.java", "_bad_credentials_exception_8java.html", [
      [ "BadCredentialsException", "classfxsrc_1_1propyecto_1_1domain_1_1_bad_credentials_exception.html", "classfxsrc_1_1propyecto_1_1domain_1_1_bad_credentials_exception" ]
    ] ],
    [ "CollaborativeFiltering.java", "_collaborative_filtering_8java.html", [
      [ "CollaborativeFiltering", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering" ],
      [ "FrequencyAndSumOfScores", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering_1_1_frequency_and_sum_of_scores.html", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering_1_1_frequency_and_sum_of_scores" ]
    ] ],
    [ "ContentBasedFiltering.java", "_content_based_filtering_8java.html", [
      [ "ContentBasedFiltering", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering" ]
    ] ],
    [ "DataManager.java", "_data_manager_8java.html", [
      [ "DataManager", "classfxsrc_1_1propyecto_1_1domain_1_1_data_manager.html", "classfxsrc_1_1propyecto_1_1domain_1_1_data_manager" ]
    ] ],
    [ "ExistingActiveUserException.java", "_existing_active_user_exception_8java.html", [
      [ "ExistingActiveUserException", "classfxsrc_1_1propyecto_1_1domain_1_1_existing_active_user_exception.html", "classfxsrc_1_1propyecto_1_1domain_1_1_existing_active_user_exception" ]
    ] ],
    [ "ExistingUsernameException.java", "_existing_username_exception_8java.html", [
      [ "ExistingUsernameException", "classfxsrc_1_1propyecto_1_1domain_1_1_existing_username_exception.html", "classfxsrc_1_1propyecto_1_1domain_1_1_existing_username_exception" ]
    ] ],
    [ "HybridApproachFiltering.java", "_hybrid_approach_filtering_8java.html", [
      [ "HybridApproachFiltering", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering" ]
    ] ],
    [ "Item.java", "_item_8java.html", [
      [ "Item", "classfxsrc_1_1propyecto_1_1domain_1_1_item.html", "classfxsrc_1_1propyecto_1_1domain_1_1_item" ]
    ] ],
    [ "ItemAttribute.java", "_item_attribute_8java.html", [
      [ "ItemAttribute", "classfxsrc_1_1propyecto_1_1domain_1_1_item_attribute.html", "classfxsrc_1_1propyecto_1_1domain_1_1_item_attribute" ]
    ] ],
    [ "ItemDoesNotExistException.java", "_item_does_not_exist_exception_8java.html", [
      [ "ItemDoesNotExistException", "classfxsrc_1_1propyecto_1_1domain_1_1_item_does_not_exist_exception.html", "classfxsrc_1_1propyecto_1_1domain_1_1_item_does_not_exist_exception" ]
    ] ],
    [ "NoExistingActiveUserException.java", "_no_existing_active_user_exception_8java.html", [
      [ "NoExistingActiveUserException", "classfxsrc_1_1propyecto_1_1domain_1_1_no_existing_active_user_exception.html", "classfxsrc_1_1propyecto_1_1domain_1_1_no_existing_active_user_exception" ]
    ] ],
    [ "NoExistingUserIDException.java", "_no_existing_user_i_d_exception_8java.html", [
      [ "NoExistingUserIDException", "classfxsrc_1_1propyecto_1_1domain_1_1_no_existing_user_i_d_exception.html", "classfxsrc_1_1propyecto_1_1domain_1_1_no_existing_user_i_d_exception" ]
    ] ],
    [ "ParserCSV.java", "_parser_c_s_v_8java.html", [
      [ "ParserCSV", "classfxsrc_1_1propyecto_1_1domain_1_1_parser_c_s_v.html", "classfxsrc_1_1propyecto_1_1domain_1_1_parser_c_s_v" ]
    ] ],
    [ "Rating.java", "_rating_8java.html", [
      [ "Rating", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html", "classfxsrc_1_1propyecto_1_1domain_1_1_rating" ]
    ] ],
    [ "RatingDoesNotExistException.java", "_rating_does_not_exist_exception_8java.html", [
      [ "RatingDoesNotExistException", "classfxsrc_1_1propyecto_1_1domain_1_1_rating_does_not_exist_exception.html", "classfxsrc_1_1propyecto_1_1domain_1_1_rating_does_not_exist_exception" ]
    ] ],
    [ "Recommender.java", "_recommender_8java.html", [
      [ "Recommender", "classfxsrc_1_1propyecto_1_1domain_1_1_recommender.html", "classfxsrc_1_1propyecto_1_1domain_1_1_recommender" ]
    ] ],
    [ "SceneManager.java", "_scene_manager_8java.html", [
      [ "SceneManager", "classfxsrc_1_1propyecto_1_1domain_1_1_scene_manager.html", "classfxsrc_1_1propyecto_1_1domain_1_1_scene_manager" ]
    ] ],
    [ "User.java", "_user_8java.html", [
      [ "User", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html", "classfxsrc_1_1propyecto_1_1domain_1_1_user" ]
    ] ],
    [ "UserActual.java", "_user_actual_8java.html", [
      [ "UserActual", "classfxsrc_1_1propyecto_1_1domain_1_1_user_actual.html", "classfxsrc_1_1propyecto_1_1domain_1_1_user_actual" ]
    ] ],
    [ "UserManager.java", "_user_manager_8java.html", [
      [ "UserManager", "classfxsrc_1_1propyecto_1_1domain_1_1_user_manager.html", "classfxsrc_1_1propyecto_1_1domain_1_1_user_manager" ]
    ] ]
];