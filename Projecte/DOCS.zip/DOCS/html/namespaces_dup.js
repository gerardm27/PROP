var namespaces_dup =
[
    [ "fxsrc", "namespacefxsrc.html", "namespacefxsrc" ]
];