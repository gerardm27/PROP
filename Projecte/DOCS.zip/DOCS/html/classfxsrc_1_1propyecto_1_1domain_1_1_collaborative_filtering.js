var classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering =
[
    [ "FrequencyAndSumOfScores", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering_1_1_frequency_and_sum_of_scores.html", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering_1_1_frequency_and_sum_of_scores" ],
    [ "CollaborativeFiltering", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#a26c45fbd43765ee5c462ee4f97e9be1a", null ],
    [ "ChangeUserBetweenClusters", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#a450a2727168dc638626a3040f7c1a2df", null ],
    [ "DistanceBetweenUsers", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#acaf1b5624faa9fe6b8fb40ae8ac44986", null ],
    [ "Kmeans", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#ae2fbfc7f8f1f7dad89e326d6e026d7e6", null ],
    [ "RatingOfOneUserToAnItem", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#aa771d627a05fd716320a8184ceca39d7", null ],
    [ "Recommend", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#a2fa93a9f5c4e9fc43a5bb71ace3ffb6a", null ],
    [ "Recommend", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#abc4902026a6e6820a10301ab4ce1cbe7", null ],
    [ "SlopeOne", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#a9b60adf017772aec4c52532e469316c5", null ],
    [ "UsersIDofSimilarUsers", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#af92f4841b8a4d48f220f7445cfa85c57", null ],
    [ "WasThatItemRatedByMainUser", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#a0208d0d8c7bee6a21105e4176832a280", null ],
    [ "centroids", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#a2b485c991f4f66d64b7fee5e79de7ded", null ],
    [ "dataset", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#a929e16bddad3c184044f33e7f6bf2bfe", null ],
    [ "K", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#ad51c8c4253e3ad751ee0b6d43832b205", null ],
    [ "Kgroups", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#a70ea0e07537acd6570064d0816603d69", null ],
    [ "KgroupsEmpty", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#a8eb6fdcfc042c76928d1e48ed885e1cc", null ],
    [ "maxRatingValue", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#a996264fde77d711e68293fb8807c5489", null ],
    [ "ratingsMap", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering.html#a72211f48845af4f720a9ed2787658212", null ]
];