var dir_65e982bbfcdcce72a4c42c2fa7c0b5a9 =
[
    [ "text", "dir_bb9a6e28dadb3329600105b66ca18c86.html", null ],
    [ "ContentBasedFilteringTest.java", "_content_based_filtering_test_8java.html", [
      [ "ContentBasedFilteringTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_content_based_filtering_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_content_based_filtering_test" ]
    ] ],
    [ "DataManagerTest.java", "_data_manager_test_8java.html", [
      [ "DataManagerTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_manager_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_manager_test" ]
    ] ],
    [ "DataRatingTest.java", "_data_rating_test_8java.html", [
      [ "DataRatingTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_rating_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_rating_test" ]
    ] ],
    [ "DataTest.java", "_data_test_8java.html", [
      [ "DataTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_test" ]
    ] ],
    [ "ItemAttributeTest.java", "_item_attribute_test_8java.html", [
      [ "ItemAttributeTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_item_attribute_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_item_attribute_test" ]
    ] ],
    [ "ItemTest.java", "_item_test_8java.html", [
      [ "ItemTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_item_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_item_test" ]
    ] ],
    [ "ParserCSVTest.java", "_parser_c_s_v_test_8java.html", [
      [ "ParserCSVTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_parser_c_s_v_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_parser_c_s_v_test" ]
    ] ],
    [ "RatingTest.java", "_rating_test_8java.html", [
      [ "RatingTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_rating_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_rating_test" ]
    ] ],
    [ "RecommenderTest.java", "_recommender_test_8java.html", [
      [ "RecommenderTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test" ]
    ] ],
    [ "UserTest.java", "_user_test_8java.html", [
      [ "UserTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_user_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_user_test" ]
    ] ]
];