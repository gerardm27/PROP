var classfxsrc_1_1propyecto_1_1drivers_1_1_collaborative_filtering_test =
[
    [ "main", "classfxsrc_1_1propyecto_1_1drivers_1_1_collaborative_filtering_test.html#aef4f0be2a5a28cd0bb28c336074dd4d8", null ],
    [ "testRecommendNR", "classfxsrc_1_1propyecto_1_1drivers_1_1_collaborative_filtering_test.html#a8308418bde2c549bfe4c3845b1f2ca05", null ],
    [ "testRecommendUserAndNR", "classfxsrc_1_1propyecto_1_1drivers_1_1_collaborative_filtering_test.html#a84f34805493dfaa4fe89b2ac201726a0", null ],
    [ "testRecommendUserRatingsAndNR", "classfxsrc_1_1propyecto_1_1drivers_1_1_collaborative_filtering_test.html#a43473c7800d56697117c163f4329fae5", null ]
];