var classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering_1_1_frequency_and_sum_of_scores =
[
    [ "FrequencyAndSumOfScores", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering_1_1_frequency_and_sum_of_scores.html#aad5f46df2d1de95cd058fcfe156740bf", null ],
    [ "frequency", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering_1_1_frequency_and_sum_of_scores.html#a9c4707237a4239749aba40bf034074db", null ],
    [ "scoreSum", "classfxsrc_1_1propyecto_1_1domain_1_1_collaborative_filtering_1_1_frequency_and_sum_of_scores.html#adba0a4cac44421b13222b82c2daf49cb", null ]
];