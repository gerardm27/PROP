var classfxsrc_1_1propyecto_1_1domain_1_1_user =
[
    [ "User", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#a79b8545a6d87f7ea1e6573e7b0d7ed7e", null ],
    [ "User", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#a839460d03a537209101fdd36ec8c716b", null ],
    [ "User", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#a8237a598f755c2cfbdcb7906abd2c212", null ],
    [ "AddToRatingsList", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#a96d83636018576a945c42f91ebdbae62", null ],
    [ "GetRatingsList", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#a074d7f417a116a47447149b3de317a5b", null ],
    [ "GetUserID", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#a37e995116ed4709e966b5eaa0f268d15", null ],
    [ "ModifyItemRating", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#a9d1daec70127daf8536250a4ca55a6c0", null ],
    [ "RemoveFromRatingsList", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#a7537afa446ef6eab0a90ca0cd0b8131c", null ],
    [ "SetRatingsList", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#a99705bca84a9b9178d934dc22f4fa528", null ],
    [ "SetUserID", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#af11f78459b8604c6b1ca5c3b6eb80224", null ],
    [ "ratingsList", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#a725228074d4556c8a4c2d1fa0e1e1ee8", null ],
    [ "userID", "classfxsrc_1_1propyecto_1_1domain_1_1_user.html#ac706907096bc624716b097cf66de0949", null ]
];