var classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller =
[
    [ "DeleteItem", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#acd029cbfa72c173bf6c631c4967234fa", null ],
    [ "GoBack", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#aaaf0518b049f9c903617cdd15fff8437", null ],
    [ "GoToFav", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#a5f93e6044a150460812c918d53f85917", null ],
    [ "GoToHome", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#a18c2b9e4e77345f7cd6479b0a4242341", null ],
    [ "GoToItem", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#acf2eac3014bb7fdbc4c64722453381f3", null ],
    [ "GoToProfile", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#a72a38c852edfc81e10d7ae8d969de218", null ],
    [ "GoToRecommend", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#ad755ce545881fb7d8f1f97322c630173", null ],
    [ "Init", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#ab559a906792e3b02f871993a9d944436", null ],
    [ "initialize", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#a04d5cb724c0dc06f5d89c1129ae2ab23", null ],
    [ "LogOut", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#a2a528b3807dacbc3b325ad4b8cefdc21", null ],
    [ "grid", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#a7588ffa1aba002de93645605a7d98eab", null ],
    [ "list", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#aec026fecedc8bf9851c8769af11020fe", null ],
    [ "scrollPane", "classfxsrc_1_1propyecto_1_1presentation_1_1_recommend_list_controller.html#a990ed69050f2a7e8f9f1ab80c0b23dea", null ]
];