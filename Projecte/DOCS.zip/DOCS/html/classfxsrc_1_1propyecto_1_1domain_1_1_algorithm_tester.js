var classfxsrc_1_1propyecto_1_1domain_1_1_algorithm_tester =
[
    [ "CBF", "classfxsrc_1_1propyecto_1_1domain_1_1_algorithm_tester.html#ad4bcf6660ff47f462f034d69db13239b", null ],
    [ "CF", "classfxsrc_1_1propyecto_1_1domain_1_1_algorithm_tester.html#aaf81784537c878977282574d8161f7cc", null ],
    [ "Hybrid", "classfxsrc_1_1propyecto_1_1domain_1_1_algorithm_tester.html#a1cdd52c5d9ac60294579bb3b05c2c0b9", null ],
    [ "ReadAndExecuteAlgorithms", "classfxsrc_1_1propyecto_1_1domain_1_1_algorithm_tester.html#a9c16aec4aa00b511c0d27a2cf5bfcfb4", null ]
];