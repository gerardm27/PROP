var classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering =
[
    [ "ContentBasedFiltering", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#a6e87989d929423b71fb11814bb9ab278", null ],
    [ "CompareItems", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#a52dad1a7b1875a04571bf6ba9ae09e7f", null ],
    [ "ComputeJaccard", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#a3f80d721e20783e085e9d52db38a43ab", null ],
    [ "ComputeKNearest", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#ae8d4cd22e86dc24485523f175d3ef81a", null ],
    [ "ComputePonderations", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#a782812cf869f90343591e74dd1fb1ddd", null ],
    [ "GetNSimilarItems", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#ab8338907acbda8b276c6468622acaf0d", null ],
    [ "PrintKNearest", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#a32bdba8ddfae570343d89e2fe2ef3086", null ],
    [ "SortArray", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#aea51a58ac03d0b97b21b2c8c8574cfd5", null ],
    [ "ALL_ITEMS_NINETY_PERCENT", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#a0f22f2a54734581c9f0ed6e82e42f122", null ],
    [ "ALL_ITEMS_TWENTY_PERCENT", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#add93782ccf17c79544df7ac5ef15807f", null ],
    [ "allItems", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#ad8fa5801d46861fd66db51dc35fe3edb", null ],
    [ "itemsSize", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#a8f759597081cdd3e1850d4969706ca19", null ],
    [ "kValue", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#ab8e77a013bd56db1ad9563309ecc1318", null ],
    [ "ponderations", "classfxsrc_1_1propyecto_1_1domain_1_1_content_based_filtering.html#aec6086fdba35cdf0329b309a1438537d", null ]
];