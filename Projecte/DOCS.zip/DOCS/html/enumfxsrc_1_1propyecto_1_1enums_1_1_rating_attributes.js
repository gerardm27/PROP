var enumfxsrc_1_1propyecto_1_1enums_1_1_rating_attributes =
[
    [ "ITEM_ID", "enumfxsrc_1_1propyecto_1_1enums_1_1_rating_attributes.html#ae022597ee2cf488d9c79dc5b0feeaaad", null ],
    [ "RATING", "enumfxsrc_1_1propyecto_1_1enums_1_1_rating_attributes.html#a2b80d4451a263547cfca018ef2ab0168", null ],
    [ "USER_ID", "enumfxsrc_1_1propyecto_1_1enums_1_1_rating_attributes.html#aed6b95e8d209dd0120bdacb08e4b44ab", null ]
];