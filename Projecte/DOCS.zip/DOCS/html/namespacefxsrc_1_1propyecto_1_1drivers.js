var namespacefxsrc_1_1propyecto_1_1drivers =
[
    [ "ContentBasedFilteringTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_content_based_filtering_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_content_based_filtering_test" ],
    [ "DataManagerTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_manager_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_manager_test" ],
    [ "DataRatingTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_rating_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_rating_test" ],
    [ "DataTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_data_test" ],
    [ "ItemAttributeTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_item_attribute_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_item_attribute_test" ],
    [ "ItemTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_item_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_item_test" ],
    [ "ParserCSVTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_parser_c_s_v_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_parser_c_s_v_test" ],
    [ "RatingTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_rating_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_rating_test" ],
    [ "RecommenderTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_recommender_test" ],
    [ "UserTest", "classfxsrc_1_1propyecto_1_1drivers_1_1_user_test.html", "classfxsrc_1_1propyecto_1_1drivers_1_1_user_test" ]
];