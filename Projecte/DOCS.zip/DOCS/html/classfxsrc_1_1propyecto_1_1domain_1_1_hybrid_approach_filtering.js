var classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering =
[
    [ "HybridApproachFiltering", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html#a625a56cc35f6f1b5fa62496fbb1eb334", null ],
    [ "Recommend", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html#a1c93fafbc6207f45913b6f3c00fd15f4", null ],
    [ "Recommend", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html#a7a73028d902f6f1e95b4b2bd07859884", null ],
    [ "RecommendInternal", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html#a9bc6e09c110a29f45aa62ddbdd17b293", null ],
    [ "COLLAB_RECOMMENDATIONS_THRESHOLD", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html#a15e0f8f076386b2dbf67ecfba75e7e73", null ],
    [ "collaborativeFiltering", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html#ac09a965a364d5d276ac52f2350f062cd", null ],
    [ "CONTENT_SIMILARITY_THRESHOLD", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html#a6579da47165eaa746e1736eeca328510", null ],
    [ "contentBasedFiltering", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html#a19bf02ce9f57f6cd029f1a30106013f9", null ],
    [ "contentBasedK", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html#ab7712eec87a9c985f5b680ef909fa11e", null ],
    [ "POSITIVE_RATING_THRESHOLD", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html#af5de4506c184bfcffa0893d220b46d25", null ],
    [ "userGroups", "classfxsrc_1_1propyecto_1_1domain_1_1_hybrid_approach_filtering.html#a829fb04ae93085e021d6e1fbe940b3fb", null ]
];