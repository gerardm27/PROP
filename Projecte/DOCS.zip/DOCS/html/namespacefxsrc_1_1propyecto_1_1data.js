var namespacefxsrc_1_1propyecto_1_1data =
[
    [ "Data", "classfxsrc_1_1propyecto_1_1data_1_1_data.html", "classfxsrc_1_1propyecto_1_1data_1_1_data" ],
    [ "DataAlgorithm", "classfxsrc_1_1propyecto_1_1data_1_1_data_algorithm.html", "classfxsrc_1_1propyecto_1_1data_1_1_data_algorithm" ],
    [ "DataItem", "classfxsrc_1_1propyecto_1_1data_1_1_data_item.html", "classfxsrc_1_1propyecto_1_1data_1_1_data_item" ],
    [ "DataRating", "classfxsrc_1_1propyecto_1_1data_1_1_data_rating.html", "classfxsrc_1_1propyecto_1_1data_1_1_data_rating" ],
    [ "DataUser", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html", "classfxsrc_1_1propyecto_1_1data_1_1_data_user" ]
];