var classfxsrc_1_1propyecto_1_1domain_1_1_recommender =
[
    [ "ComputeDCG", "classfxsrc_1_1propyecto_1_1domain_1_1_recommender.html#a0d700ffe0a83a137e46a49b4fc9d9ab8", null ],
    [ "ComputeIDCG", "classfxsrc_1_1propyecto_1_1domain_1_1_recommender.html#aebf9164de78aee0a55c322f622feb13b", null ],
    [ "ComputeNDCG", "classfxsrc_1_1propyecto_1_1domain_1_1_recommender.html#a2b7c8b85744a4552e0cbb2a9b7796439", null ],
    [ "GetIndexGivenItemID", "classfxsrc_1_1propyecto_1_1domain_1_1_recommender.html#a46b206a88721b9b7072fa65511ec56bc", null ],
    [ "Log2", "classfxsrc_1_1propyecto_1_1domain_1_1_recommender.html#aa6a9fc1777e8743dbdabacd3240b53bf", null ]
];