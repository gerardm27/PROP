var classfxsrc_1_1propyecto_1_1presentation_1_1_liked_list_controller =
[
    [ "GoBack", "classfxsrc_1_1propyecto_1_1presentation_1_1_liked_list_controller.html#a9961143c4c618b13687f81a12036f23c", null ],
    [ "GoToFav", "classfxsrc_1_1propyecto_1_1presentation_1_1_liked_list_controller.html#a76ad0aa4028f09f34b45454b73c321af", null ],
    [ "GoToHome", "classfxsrc_1_1propyecto_1_1presentation_1_1_liked_list_controller.html#abbab8c3771a2c05fc26ae915861f1dd9", null ],
    [ "GoToItem", "classfxsrc_1_1propyecto_1_1presentation_1_1_liked_list_controller.html#a09daa796dab840a8425f91a2eb7a7b17", null ],
    [ "GoToProfile", "classfxsrc_1_1propyecto_1_1presentation_1_1_liked_list_controller.html#a20da6246dccc11a01472d5ceae3942a6", null ],
    [ "GoToRecommend", "classfxsrc_1_1propyecto_1_1presentation_1_1_liked_list_controller.html#a92c4f03308b283f6366ac3812cf908ea", null ],
    [ "initialize", "classfxsrc_1_1propyecto_1_1presentation_1_1_liked_list_controller.html#a9d028295bbfac5ee43aaf7e32539599b", null ],
    [ "LogOut", "classfxsrc_1_1propyecto_1_1presentation_1_1_liked_list_controller.html#a795420275fdf53316c20577c0a8e9926", null ],
    [ "scrollPane", "classfxsrc_1_1propyecto_1_1presentation_1_1_liked_list_controller.html#a91f8fddc9f9a12393219eadb6d612744", null ]
];