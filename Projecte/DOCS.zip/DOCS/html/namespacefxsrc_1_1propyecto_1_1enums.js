var namespacefxsrc_1_1propyecto_1_1enums =
[
    [ "ItemTypes", "enumfxsrc_1_1propyecto_1_1enums_1_1_item_types.html", "enumfxsrc_1_1propyecto_1_1enums_1_1_item_types" ],
    [ "RatingAttributes", "enumfxsrc_1_1propyecto_1_1enums_1_1_rating_attributes.html", "enumfxsrc_1_1propyecto_1_1enums_1_1_rating_attributes" ]
];