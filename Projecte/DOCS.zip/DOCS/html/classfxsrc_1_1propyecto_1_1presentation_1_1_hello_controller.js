var classfxsrc_1_1propyecto_1_1presentation_1_1_hello_controller =
[
    [ "onHelloButtonClick", "classfxsrc_1_1propyecto_1_1presentation_1_1_hello_controller.html#a07f91454a3a0733cd619762014391bc8", null ],
    [ "welcomeText", "classfxsrc_1_1propyecto_1_1presentation_1_1_hello_controller.html#af20921c3787574b5b0b611191bd47459", null ]
];