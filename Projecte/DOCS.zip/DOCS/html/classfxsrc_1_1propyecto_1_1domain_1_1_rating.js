var classfxsrc_1_1propyecto_1_1domain_1_1_rating =
[
    [ "Rating", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#af09ba9d8d673b4722f9d51aa6482b106", null ],
    [ "Rating", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#a753dce1662a97157b537ca17aa0863ff", null ],
    [ "Equals", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#a9ccbc0ef3aca4dc59176b77b84ae94e9", null ],
    [ "GetItemID", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#a96f7b6cd9b84bf75caa041c10e8899be", null ],
    [ "GetRating", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#ae98715823ebbf180c5eeb66cd2a1a0fe", null ],
    [ "GetUserID", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#ae43daccb383659ea532393665aa15d7c", null ],
    [ "SetItemID", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#a76514b759f49a2ff8b2a820224a41130", null ],
    [ "SetRating", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#a33e662bbb8bb6c78eb2909335b29f121", null ],
    [ "SetUserID", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#a580cee9ad2e2d17f6b4fd575827e722a", null ],
    [ "itemID", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#a3104f1a328a57a093ffc0f50b237eccf", null ],
    [ "rating", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#a811765e98ab2ed3afa1e42b51ab9e232", null ],
    [ "userID", "classfxsrc_1_1propyecto_1_1domain_1_1_rating.html#aa4f3e292922ad4055ac13edad08c11bb", null ]
];