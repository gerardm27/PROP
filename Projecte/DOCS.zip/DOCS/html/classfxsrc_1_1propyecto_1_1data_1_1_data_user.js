var classfxsrc_1_1propyecto_1_1data_1_1_data_user =
[
    [ "DataUser", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a132d800e2387b1c57374dc23d348853f", null ],
    [ "AddUser", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a7710fd08d8689ca3cc3e495cc80533c1", null ],
    [ "CheckCredentials", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#af74d97b4e2c29a517db6e6552e86dae0", null ],
    [ "ClearData", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#aca5a1d759a0cfd8095ef453665ea578e", null ],
    [ "DeleteUser", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a28a6ecd5563836012c3638347f321e1b", null ],
    [ "GetFreeID", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a7e10993abc5c2d83e385edc0a6398fee", null ],
    [ "GetNextLine", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a29a99a2eed840b340e8fbc8041ceee0d", null ],
    [ "GetUser", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a6d09c101e034cc1e1688d1880970796b", null ],
    [ "HasNextLine", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#ac579cf84e9e7d24cc3670765526e5170", null ],
    [ "Init", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a1db523964ed2e73c1a5e5a2677acf2c3", null ],
    [ "ParseAndAddData", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#ad96dbf6eb1727104f3da1be0e1f839c5", null ],
    [ "Print", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a2b07e4ee44b8d54873808a8cdb0948d1", null ],
    [ "SetNewEmail", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a5a36c1cd987f19e490442e66d0fbe032", null ],
    [ "SetNewPassword", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#ad40fa501eb667111f0d383ed30d8b77d", null ],
    [ "SetNewSecurity", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#aec90a0475eb562b2fceb9b3bea0bb76d", null ],
    [ "SetNewUsername", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#abbc9c462cb46c42511b88c07ef7b3133", null ],
    [ "SetRatings", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a7191b49cd0e560acde397f799793c502", null ],
    [ "UserExists", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a8f14699a08b06e1ca82891b97bd7699e", null ],
    [ "systemUsers", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#aed3a7832d5cb97261df0350e5001e771", null ],
    [ "usersArray", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a2cbcff010aa165170b5089e8d17de017", null ],
    [ "usersIds", "classfxsrc_1_1propyecto_1_1data_1_1_data_user.html#a25640b3979829c480675c1cfc0fa6930", null ]
];